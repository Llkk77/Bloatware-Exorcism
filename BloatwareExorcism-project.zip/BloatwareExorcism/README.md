# Bloatware Exorcism

**by ChatGPT**

Versão 0.3.0. Aplicativo Android offline para revisar componentes pré-instalados do MIUI e HyperOS, com prioridade inicial em ROMs oficiais Global e China e Android 16 com KernelSU.

A interface é inteiramente em inglês e usa Material Design 3: componentes oficiais Material Web locais, Roboto, superfícies tonais, cores dinâmicas do Android e tema escuro. A paleta azul é usada como fallback. Veja docs/MATERIAL3.md para componentes, acessibilidade, movimento e verificações.

## Novidades 0.3.0

- Interface Material 3 com cores do sistema, tipografia Roboto e componentes oficiais empacotados offline.
- Botões, caixas de seleção, campo de busca, filtros, seletores, diálogos e progresso Material.
- Navegação adaptativa, ripple, transições, foco visível, suporte a movimento reduzido e escala de texto do Android.
- Testes automatizados de acessibilidade, contraste, layout e teclado.
- Mesma chave de desenvolvimento da versão 0.2.2; pode atualizar essa versão sem desinstalação. Mantenha backups exportados.

## Novidades 0.2.2

- Barra de navegação do Android oculta durante o uso e restaurável por gesto do sistema. A janela agora reserva os insets em um contêiner externo à WebView e consome os insets já aplicados, incluindo teclado e recortes.
- Menu inferior: Home, Packages, Backups, Restore e Advanced. A identidade Exorcise/Detect Demons/Holy Backup/Resurrection/Deep Exorcism permanece nas funções.
- Botões explícitos: Grant root access, Scan installed apps, Create backup, Restore packages, Disable selected e Remove selected.
- Remoção ou desativação comum em um toque após seleção manual, com Holy Backup automático antes do lote. A ação vale apenas para o usuário atual; a remoção preserva os arquivos originais do sistema e solicita retenção de dados com -k. Pacotes avançados continuam exigindo revisão, e componentes protegidos não podem ser selecionados.
- Painel de ações fixo acima do menu inferior; seleção não dispara operações. Limite de 30 pacotes por lote mantido.

## Novidades 0.2.1

- Tema totalmente escuro em preto e azul, incluindo a janela nativa e o ícone.
- Interface, catálogo e mensagens do aplicativo em inglês, com formatação de datas en-US.
- Operações root e formatos dos backups preservados.

## Novidades 0.2.0

- Relatório JSON de validação exportável em Resurrection: modelo, ROM, fingerprint, ações, resultados e checklists de teste funcional.
- Os relatos identificam evidência declarada pelo usuário e conferência do estado. Um patch de validatedBuilds só é proposto com funções exigidas aprovadas, estado da ação ainda aplicado e um boot posterior observado. Não altera o catálogo embarcado automaticamente nem significa garantia para outros aparelhos.
- Exportação de fixture real na inspeção do pacote. O trecho é limitado ao bloco do usuário, com inodes zerados, e inclui estado independente obtido pelo PackageManager antes/depois da captura. A captura deve ser estável.
- Parser reforçado para campos quebrados em linhas, espaços/tabulações e CRLF, rejeitando blocos/campos repetidos e estados inválidos.
- Onze fixtures SINTÉTICAS para regressão. Nenhuma captura MIUI/HyperOS real foi obtida durante esta implementação. Use o coletor em aparelhos e scripts/import_fixture.py para aumentar a base com origem preservada.
- Módulo KernelSU opcional de resgate experimental, com armamento antes do lote, verificação de fingerprint, monitor de boot, rollback e confirmação manual após reinício. Leia rescue-module/README.md antes de instalar. Não foi testado em aparelho.

## Funcionalidades

| Tela | Implementação desta versão |
|---|---|
| Exorcise | Seleção manual, desativação e remoção por usuário de pacotes de sistema classificados |
| Detect Demons | Inventário real via PackageManager, pesquisa, categorias, proteção e inspeção de services/receivers/providers |
| Holy Backup | Registros locais automáticos e manuais, exportação/importação JSON, comparação e restauração de estados |
| Resurrection | Histórico persistente, restauração do pacote original e do estado de ativação anterior |
| Deep Exorcism | Habilitação explícita de pacotes avançados, auditoria de serviços init e Binder e consulta dumpsys |

Catálogo inicial: 139 pacotes. A classificação é comunitária; nenhuma build de aparelho físico foi validada por este projeto. Pacote encontrado não significa serviço ativo ou impacto de desempenho comprovado.

## Instalação e uso

1. Instale a versão 0.3.0 sobre a 0.2.2: a assinatura de desenvolvimento foi preservada. Para versões anteriores com outro certificado, exporte seus backups antes de substituir o app, pois desinstalar apaga os registros internos.
2. No KernelSU, autorize `dev.bloatware.exorcism` para executar `su` com UID 0. Perfis SELinux/capabilities personalizados podem impedir comandos mesmo com UID 0; o app exibirá o resultado.
3. Abra o app e toque em Grant root access.
4. Crie um Holy Backup e exporte uma cópia para um local escolhido pelo seletor de arquivos do Android.
5. Revise os pacotes antes de selecionar. Experimente a desativação de um pacote por vez, confira as funções do aparelho e use Resurrection para voltar.

Apenas o usuário Android em que o app está executando pode ser alterado, e ele precisa ser o usuário ativo. Não há operação automática em outros perfis. O relatório exportado pode conter a lista de pacotes, ROM, fingerprint e seus relatos; revise-o antes de compartilhar. Não inclui serial do aparelho.

## Limites de recuperação

Holy Backup registra pacotes e estados, ROM, usuário e o histórico do app. Não inclui dados privados de outros apps, fotos, bancos de dados, partições ou imagem de firmware. Não equivale a backup integral do aparelho.

A remoção usa `pm uninstall -k --user ID`. Os arquivos originais do pacote de sistema permanecem; isso não libera o espaço ocupado por esses arquivos na partição do sistema. O parâmetro `-k` solicita preservação de dados, sem garantir recuperação de todas as informações ou relações de dependência.

Resurrection usa `cmd package install-existing --user ID` e restaura o estado original de ativação. Restaurações exigem a mesma fingerprint de firmware e usuário. Depois de uma OTA, reavalie a compatibilidade. Registros criados por outras ferramentas não são inferidos automaticamente.

A restauração de Holy Backup considera apenas pacotes classificados e não protegidos, reinstalando ou ajustando estados. Não remove pacotes instalados depois do registro. Backups importados não importam um histórico executável; a comparação usa estados validados e o catálogo local. Limite de 30 alterações por lote.

O histórico usa gravação atômica antes dos comandos. Timeout ou interrupção pode deixar uma operação marcada como pendente ou incerta; o resultado não é tratado como sucesso sem confirmação. Não repita uma remoção incerta sem conferir o estado e o histórico.

## Proteções e escopo

- Comandos construídos exclusivamente a partir de ações fixas e identificadores validados.
- Componentes centrais, pacotes persistentes, UIDs de sistema, administradores detectados, launcher, discador, SMS, teclado, acessibilidade e serviços padrão detectados são protegidos.
- Pacotes sem classificação ficam em modo de inspeção.
- Recursos avançados exigem habilitação na sessão e confirmação do lote. Remoção e desativação comuns são aplicadas diretamente pelo botão após seleção explícita; o app cria backup antes dos comandos.
- O módulo de resgate é separado, opcional e precisa ser instalado/armado explicitamente. Não foi instalado em nenhum aparelho nesta implementação.
- Não há exclusão de arquivos em `/system`, `/product` ou `/vendor`, interrupção de serviços nativos, edição de propriedades, remoção de drivers, módulos do kernel ou desativação térmica.
- Não há métricas de CPU, bateria, FPS ou wakelocks nesta versão. A tela de serviços distingue declaração em manifesto de execução consultada por dumpsys.
- Sem permissão INTERNET, anúncios ou analytics. As bibliotecas Material da interface e a fonte são incluídas no APK; não há carregamento por CDN.
- A interface roda em Android System WebView local, com acesso de rede, navegação externa e acesso genérico a arquivos bloqueados. O bridge só expõe operações fixas.

O inventário completo é a função central do gerenciador, incluindo pacotes desconhecidos e componentes protegidos; por isso QUERY_ALL_PACKAGES é intencional. O aviso específico do lint está suprimido no elemento dessa permissão. JavaScript é necessário para a interface local; a supressão correspondente é limitada à inicialização da WebView, com CSP, escape de dados e navegação/rede bloqueadas.

## Compilação

Requisitos: JDK 17, Android SDK Platform 36 e Build Tools 36.0.0. O projeto usa Android Gradle Plugin 8.10.1 e Gradle 8.11.1. Android mínimo: API 29; target/compile: API 36. Não contém bibliotecas nativas de arquitetura específica.

Abra esta pasta no Android Studio e sincronize, ou configure `ANDROID_HOME` e execute:

```sh
./gradlew assembleDebug lintDebug
```

Saída: `app/build/outputs/apk/debug/app-debug.apk`.

O APK de testes usa certificado de desenvolvimento. A chave desta versão é entregue separadamente em BloatwareExorcism-debug.keystore para permitir manter a assinatura em futuras compilações. Preserve-a em local privado; não a inclua em repositórios públicos nem a use como chave de produção. O alias é androiddebugkey; as senhas padrão de desenvolvimento são android. Para reutilizá-la, execute:

```sh
./gradlew assembleDebug lintDebug -PexorcismDebugKeystore=/caminho/absoluto/BloatwareExorcism-debug.keystore
```

 Para distribuição, gere uma chave própria e configure assinatura de release; não publique a chave privada. Exporte os registros antes de instalar uma versão assinada com certificado diferente.

## Verificação

Teste de política sem Android:

```sh
mkdir -p /tmp/exorcism-tests
javac -d /tmp/exorcism-tests app/src/main/java/dev/bloatware/exorcism/Policy.java tests/PolicyTest.java
java -cp /tmp/exorcism-tests dev.bloatware.exorcism.PolicyTest
```

O teste verifica nomes de pacotes malformados, proteção de componentes, isolamento de usuário no parser e comandos de restauração. Teste das fixtures:

```sh
javac -d /tmp/exorcism-tests app/src/main/java/dev/bloatware/exorcism/Policy.java tests/FixtureTest.java
java -cp /tmp/exorcism-tests dev.bloatware.exorcism.FixtureTest tests/fixtures
```

Teste do resgate simulado (requer Linux, flock e diretório temporário com dono root para exercer a verificação de propriedade):

```sh
sudo python3 tests/test_rescue.py
```

A compilação/lint e os testes de interface não substituem validação root em aparelho físico.

Abra `app/src/main/assets/index.html` em um navegador para uma prévia visual com dados explicitamente ilustrativos. A prévia não simula sucesso de alterações.

## Fontes do catálogo

O catálogo contém descrições curtas próprias e identificadores públicos como pontos de investigação. Não copia os códigos das ferramentas consultadas. Ações e classificações são conservadoras e não herdam automaticamente os rótulos "safe" dessas fontes.

- https://github.com/Universal-Debloater-Alliance/universal-android-debloater-next-generation
- https://github.com/ovsky/hyperos-debloater
- https://github.com/purainity/myron-hyperos-analysis
- https://privacy.mi.com/taplus-share/en_US/
- https://developer.android.com/about/versions/16/setup-sdk
- https://kernelsu.org/guide/app-profile.html

## Próximos passos

Validar primeiro um aparelho Global e um chinês com modelo, fingerprint e resultados de cada alteração; adicionar métricas reais e regras por firmware; estudar operações nativas isoladas somente com evidência e reversão verificável.
